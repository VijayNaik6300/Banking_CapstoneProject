package com.icici.config;

import java.time.LocalDate;
import java.time.LocalDateTime;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.icici.model.Customer;
import com.icici.model.CustomerStatus;
import com.icici.repository.CustomerRepository;

@Configuration
public class DemoDataConfig {
    @Bean
    CommandLineRunner loadDemoData(CustomerRepository repo){
        return args->{
            if(repo.count()>0)return;
            save(repo,"CUST-DEMO000001","Rahul Sharma","rahul.sharma@example.com","9876543210","Mumbai, Maharashtra",LocalDate.of(1998,5,12));
            save(repo,"CUST-DEMO000002","Priya Nair","priya.nair@example.com","9876543211","Thane, Maharashtra",LocalDate.of(1999,8,21));
            save(repo,"CUST-DEMO000003","Arjun Mehta","arjun.mehta@example.com","9876543212","Bengaluru, Karnataka",LocalDate.of(1997,11,3));
        };
    }
    private void save(CustomerRepository repo,String no,String name,String email,String phone,String address,LocalDate dob){Customer c=new Customer();c.setCustomerNumber(no);c.setName(name);c.setEmail(email);c.setPhone(phone);c.setAddress(address);c.setDateOfBirth(dob);c.setStatus(CustomerStatus.ACTIVE);c.setCreatedAt(LocalDateTime.now());repo.save(c);}
}
