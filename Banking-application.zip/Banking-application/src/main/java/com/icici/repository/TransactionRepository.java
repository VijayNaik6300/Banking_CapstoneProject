package com.icici.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.icici.model.Transaction;
import com.icici.model.TransactionType;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    Optional<Transaction> findByTransactionReference(String transactionReference);
    List<Transaction> findByAccountIdOrderByCreatedAtDesc(Long accountId);
    List<Transaction> findByAccountIdAndTransactionTypeOrderByCreatedAtDesc(Long accountId, TransactionType transactionType);
    boolean existsByTransactionReference(String transactionReference);
}
