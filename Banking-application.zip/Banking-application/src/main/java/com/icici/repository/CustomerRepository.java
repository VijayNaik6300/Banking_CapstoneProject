package com.icici.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.icici.model.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
    Optional<Customer> findByEmailIgnoreCase(String email);
    Optional<Customer> findByPhone(String phone);
    boolean existsByEmailIgnoreCase(String email);
    boolean existsByPhone(String phone);
    boolean existsByCustomerNumber(String customerNumber);
}
