package com.icici.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;
import com.icici.model.CustomerStatus;

public class CustomerResponse {
    private Long id;
    private String customerNumber;
    private String name;
    private String email;
    private String phone;
    private String address;
    private LocalDate dateOfBirth;
    private CustomerStatus status;
    private LocalDateTime createdAt;
    public CustomerResponse() {}
    public Long getId(){return id;} public void setId(Long v){id=v;}
    public String getCustomerNumber(){return customerNumber;} public void setCustomerNumber(String v){customerNumber=v;}
    public String getName(){return name;} public void setName(String v){name=v;}
    public String getEmail(){return email;} public void setEmail(String v){email=v;}
    public String getPhone(){return phone;} public void setPhone(String v){phone=v;}
    public String getAddress(){return address;} public void setAddress(String v){address=v;}
    public LocalDate getDateOfBirth(){return dateOfBirth;} public void setDateOfBirth(LocalDate v){dateOfBirth=v;}
    public CustomerStatus getStatus(){return status;} public void setStatus(CustomerStatus v){status=v;}
    public LocalDateTime getCreatedAt(){return createdAt;} public void setCreatedAt(LocalDateTime v){createdAt=v;}
}
