package com.icici.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.icici.dto.CustomerPatchRequest;
import com.icici.dto.CustomerRequest;
import com.icici.dto.CustomerResponse;
import com.icici.exception.CustomerNotFoundException;
import com.icici.exception.DuplicateCustomerException;
import com.icici.model.Customer;
import com.icici.model.CustomerStatus;
import com.icici.repository.CustomerRepository;

@Service
public class CustomerService {
    private final CustomerRepository customerRepository;
    public CustomerService(CustomerRepository customerRepository){this.customerRepository=customerRepository;}

    @Transactional
    public CustomerResponse createCustomer(CustomerRequest request){
        String email=normalizeEmail(request.getEmail()); String phone=normalizePhone(request.getPhone());
        if(customerRepository.existsByEmailIgnoreCase(email)) throw new DuplicateCustomerException("Customer already exists with email: "+email);
        if(customerRepository.existsByPhone(phone)) throw new DuplicateCustomerException("Customer already exists with phone: "+phone);
        Customer c=new Customer(); c.setCustomerNumber(generateCustomerNumber()); c.setName(request.getName().trim()); c.setEmail(email); c.setPhone(phone); c.setAddress(request.getAddress().trim()); c.setDateOfBirth(request.getDateOfBirth()); c.setStatus(CustomerStatus.ACTIVE); c.setCreatedAt(LocalDateTime.now());
        return toResponse(customerRepository.save(c));
    }
    @Transactional(readOnly=true) public List<CustomerResponse> getAllCustomers(){return customerRepository.findAll().stream().map(this::toResponse).toList();}
    @Transactional(readOnly=true) public CustomerResponse getCustomerById(Long id){return toResponse(getCustomer(id));}

    @Transactional
    public CustomerResponse updateCustomer(Long id, CustomerRequest request){
        Customer c=getCustomer(id); String email=normalizeEmail(request.getEmail()); String phone=normalizePhone(request.getPhone());
        if(!email.equalsIgnoreCase(c.getEmail()) && customerRepository.existsByEmailIgnoreCase(email)) throw new DuplicateCustomerException("Email already belongs to another customer");
        if(!phone.equals(c.getPhone()) && customerRepository.existsByPhone(phone)) throw new DuplicateCustomerException("Phone already belongs to another customer");
        c.setName(request.getName().trim()); c.setEmail(email); c.setPhone(phone); c.setAddress(request.getAddress().trim()); c.setDateOfBirth(request.getDateOfBirth());
        return toResponse(customerRepository.save(c));
    }
    @Transactional
    public CustomerResponse patchCustomer(Long id, CustomerPatchRequest r){
        Customer c=getCustomer(id);
        if(r.getName()!=null && !r.getName().isBlank()) c.setName(r.getName().trim());
        if(r.getEmail()!=null && !r.getEmail().isBlank()){String email=normalizeEmail(r.getEmail()); if(!email.equalsIgnoreCase(c.getEmail())&&customerRepository.existsByEmailIgnoreCase(email)) throw new DuplicateCustomerException("Email already belongs to another customer"); c.setEmail(email);}
        if(r.getPhone()!=null && !r.getPhone().isBlank()){String phone=normalizePhone(r.getPhone()); if(!phone.equals(c.getPhone())&&customerRepository.existsByPhone(phone)) throw new DuplicateCustomerException("Phone already belongs to another customer"); c.setPhone(phone);}
        if(r.getAddress()!=null && !r.getAddress().isBlank()) c.setAddress(r.getAddress().trim());
        if(r.getDateOfBirth()!=null) c.setDateOfBirth(r.getDateOfBirth());
        return toResponse(customerRepository.save(c));
    }
    @Transactional public CustomerResponse deactivateCustomer(Long id){Customer c=getCustomer(id);c.setStatus(CustomerStatus.INACTIVE);return toResponse(customerRepository.save(c));}
    @Transactional public CustomerResponse activateCustomer(Long id){Customer c=getCustomer(id);c.setStatus(CustomerStatus.ACTIVE);return toResponse(customerRepository.save(c));}
    private Customer getCustomer(Long id){return customerRepository.findById(id).orElseThrow(()->new CustomerNotFoundException("Customer not found with id: "+id));}
    private String generateCustomerNumber(){String n; do{n="CUST-"+UUID.randomUUID().toString().replace("-","").substring(0,12).toUpperCase();}while(customerRepository.existsByCustomerNumber(n)); return n;}
    private String normalizeEmail(String e){return e.trim().toLowerCase();} private String normalizePhone(String p){return p.trim();}
    private CustomerResponse toResponse(Customer c){CustomerResponse r=new CustomerResponse();r.setId(c.getId());r.setCustomerNumber(c.getCustomerNumber());r.setName(c.getName());r.setEmail(c.getEmail());r.setPhone(c.getPhone());r.setAddress(c.getAddress());r.setDateOfBirth(c.getDateOfBirth());r.setStatus(c.getStatus());r.setCreatedAt(c.getCreatedAt());return r;}
}
