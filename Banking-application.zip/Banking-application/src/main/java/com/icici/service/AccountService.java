package com.icici.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.icici.dto.AccountRequest;
import com.icici.dto.AccountResponse;
import com.icici.exception.AccountNotFoundException;
import com.icici.exception.AccountOperationException;
import com.icici.exception.CustomerNotFoundException;
import com.icici.model.*;
import com.icici.repository.AccountRepository;
import com.icici.repository.CustomerRepository;
import com.icici.repository.TransactionRepository;

@Service
public class AccountService {
    private final AccountRepository accountRepository; private final CustomerRepository customerRepository; private final TransactionRepository transactionRepository; private final NotificationService notificationService;
    public AccountService(AccountRepository a, CustomerRepository c, TransactionRepository t, NotificationService n){accountRepository=a;customerRepository=c;transactionRepository=t;notificationService=n;}

    @Transactional
    public AccountResponse createAccount(Long customerId, AccountRequest request){
        Customer c=customerRepository.findById(customerId).orElseThrow(()->new CustomerNotFoundException("Customer not found with id: "+customerId));
        if(c.getStatus()!=CustomerStatus.ACTIVE) throw new AccountOperationException("Cannot create account for an inactive or blocked customer");
        BigDecimal opening=request.getInitialBalance()==null?BigDecimal.ZERO:money(request.getInitialBalance());
        Account a=new Account(); a.setAccountNumber(generateAccountNumber()); a.setCustomer(c); a.setAccountType(request.getAccountType()); a.setBalance(opening); a.setStatus(AccountStatus.ACTIVE); a.setCreatedAt(LocalDateTime.now()); a.setVersion(0L); accountRepository.save(a);
        if(opening.compareTo(BigDecimal.ZERO)>0){Transaction tx=buildTransaction(a,TransactionType.DEPOSIT,opening,opening,null,"Initial account funding"); transactionRepository.save(tx); notificationService.createNotification(c.getId(),NotificationType.DEPOSIT,"₹"+opening+" deposited as initial funding into account "+a.getAccountNumber()+". Available balance: ₹"+opening,tx.getTransactionReference());}
        return toResponse(a);
    }
    @Transactional(readOnly=true) public AccountResponse getAccountByNumber(String n){return toResponse(getAccount(n));}
    @Transactional public AccountResponse updateAccount(String n,AccountRequest r){Account a=getAccount(n);if(a.getStatus()==AccountStatus.CLOSED)throw new AccountOperationException("Closed account cannot be updated");a.setAccountType(r.getAccountType());return toResponse(accountRepository.save(a));}
    @Transactional public AccountResponse activateAccount(String n){Account a=getAccount(n);if(a.getStatus()==AccountStatus.CLOSED)throw new AccountOperationException("Closed account cannot be activated");a.setStatus(AccountStatus.ACTIVE);return toResponse(accountRepository.save(a));}
    @Transactional public AccountResponse deactivateAccount(String n){Account a=getAccount(n);if(a.getStatus()==AccountStatus.CLOSED)throw new AccountOperationException("Closed account cannot be deactivated");a.setStatus(AccountStatus.INACTIVE);return toResponse(accountRepository.save(a));}
    @Transactional public AccountResponse closeAccount(String n){Account a=getAccount(n);if(a.getBalance().compareTo(BigDecimal.ZERO)!=0)throw new AccountOperationException("Account balance must be zero before closing the account");a.setStatus(AccountStatus.CLOSED);return toResponse(accountRepository.save(a));}
    private Account getAccount(String n){if(n==null||n.isBlank())throw new AccountNotFoundException("Account number is required");return accountRepository.findByAccountNumber(n.trim()).orElseThrow(()->new AccountNotFoundException("Account not found with account number: "+n));}
    private String generateAccountNumber(){String n;do{n=String.valueOf(1000000000L+(long)(Math.random()*899999999L));}while(accountRepository.existsByAccountNumber(n));return n;}
    private BigDecimal money(BigDecimal b){if(b.scale()>2)throw new AccountOperationException("Amount cannot have more than 2 decimal places");return b.setScale(2);}
    private Transaction buildTransaction(Account a,TransactionType type,BigDecimal amount,BigDecimal balance,String transfer,String desc){Transaction t=new Transaction();t.setTransactionReference("TXN-"+UUID.randomUUID().toString().replace("-","").substring(0,20).toUpperCase());t.setAccount(a);t.setTransactionType(type);t.setAmount(amount);t.setBalanceAfter(balance);t.setTransferReference(transfer);t.setDescription(desc);t.setCreatedAt(LocalDateTime.now());return t;}
    private AccountResponse toResponse(Account a){return new AccountResponse(a.getId(),a.getAccountNumber(),a.getCustomer().getId(),a.getCustomer().getCustomerNumber(),a.getAccountType(),a.getBalance(),a.getStatus(),a.getCreatedAt());}
}
