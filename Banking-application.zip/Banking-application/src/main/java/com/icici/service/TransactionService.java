package com.icici.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.icici.dto.TransactionRequest;
import com.icici.dto.TransactionResponse;
import com.icici.dto.TransferRequest;
import com.icici.exception.AccountNotFoundException;
import com.icici.exception.AccountOperationException;
import com.icici.exception.TransactionNotFoundException;
import com.icici.model.*;
import com.icici.repository.AccountRepository;
import com.icici.repository.TransactionRepository;

@Service
public class TransactionService {
    private final AccountRepository accountRepository; private final TransactionRepository transactionRepository; private final NotificationService notificationService;
    public TransactionService(AccountRepository a,TransactionRepository t,NotificationService n){accountRepository=a;transactionRepository=t;notificationService=n;}

    @Transactional
    public TransactionResponse deposit(String accountNumber,TransactionRequest r){Account a=getAccountForUpdate(accountNumber);validateActive(a);BigDecimal amount=validateAmount(r.getAmount());BigDecimal newBalance=money(a.getBalance().add(amount));a.setBalance(newBalance);accountRepository.save(a);Transaction tx=build(a,TransactionType.DEPOSIT,amount,newBalance,null,r.getDescription());Transaction saved=transactionRepository.save(tx);notificationService.createNotification(a.getCustomer().getId(),NotificationType.DEPOSIT,"₹"+amount+" deposited into account "+a.getAccountNumber()+". Available balance: ₹"+newBalance,saved.getTransactionReference());return toResponse(saved);}

    @Transactional
    public TransactionResponse withdraw(String accountNumber,TransactionRequest r){Account a=getAccountForUpdate(accountNumber);validateActive(a);BigDecimal amount=validateAmount(r.getAmount());if(a.getBalance().compareTo(amount)<0)throw new AccountOperationException("Insufficient balance");BigDecimal newBalance=money(a.getBalance().subtract(amount));a.setBalance(newBalance);accountRepository.save(a);Transaction tx=build(a,TransactionType.WITHDRAWAL,amount,newBalance,null,r.getDescription());Transaction saved=transactionRepository.save(tx);notificationService.createNotification(a.getCustomer().getId(),NotificationType.WITHDRAWAL,"₹"+amount+" withdrawn from account "+a.getAccountNumber()+". Available balance: ₹"+newBalance,saved.getTransactionReference());return toResponse(saved);}

    @Transactional
    public TransactionResponse transfer(String sourceNumber,TransferRequest r){String src=sourceNumber.trim(),dst=r.getDestinationAccountNumber().trim();if(src.equals(dst))throw new AccountOperationException("Source and destination accounts cannot be the same");BigDecimal amount=validateAmount(r.getAmount());Account first,second;if(src.compareTo(dst)<0){first=getAccountForUpdate(src);second=getAccountForUpdate(dst);}else{first=getAccountForUpdate(dst);second=getAccountForUpdate(src);}Account source=src.equals(first.getAccountNumber())?first:second;Account destination=dst.equals(first.getAccountNumber())?first:second;validateActive(source);validateActive(destination);if(source.getBalance().compareTo(amount)<0)throw new AccountOperationException("Insufficient balance in source account");String transferRef="TRF-"+UUID.randomUUID().toString().replace("-","").substring(0,20).toUpperCase();BigDecimal sourceBalance=money(source.getBalance().subtract(amount));BigDecimal destinationBalance=money(destination.getBalance().add(amount));source.setBalance(sourceBalance);destination.setBalance(destinationBalance);accountRepository.save(source);accountRepository.save(destination);Transaction debit=transactionRepository.save(build(source,TransactionType.TRANSFER_DEBIT,amount,sourceBalance,transferRef,r.getDescription()));Transaction credit=transactionRepository.save(build(destination,TransactionType.TRANSFER_CREDIT,amount,destinationBalance,transferRef,r.getDescription()));notificationService.createNotification(source.getCustomer().getId(),NotificationType.TRANSFER,"₹"+amount+" transferred from account "+source.getAccountNumber()+" to account "+destination.getAccountNumber()+". Available balance: ₹"+sourceBalance,debit.getTransactionReference());notificationService.createNotification(destination.getCustomer().getId(),NotificationType.TRANSFER,"₹"+amount+" received in account "+destination.getAccountNumber()+" from account "+source.getAccountNumber()+". Available balance: ₹"+destinationBalance,credit.getTransactionReference());return toResponse(debit);}

    @Transactional(readOnly=true) public List<TransactionResponse> getTransactionHistory(String n){Account a=getAccount(n);return transactionRepository.findByAccountIdOrderByCreatedAtDesc(a.getId()).stream().map(this::toResponse).toList();}
    @Transactional(readOnly=true) public List<TransactionResponse> getTransactionsByType(String n,TransactionType type){if(type==null)throw new AccountOperationException("Transaction type is required");Account a=getAccount(n);return transactionRepository.findByAccountIdAndTransactionTypeOrderByCreatedAtDesc(a.getId(),type).stream().map(this::toResponse).toList();}
    @Transactional(readOnly=true) public TransactionResponse getTransactionByReference(String ref){Transaction t=transactionRepository.findByTransactionReference(ref).orElseThrow(()->new TransactionNotFoundException("Transaction not found with reference: "+ref));return toResponse(t);}

    private Transaction build(Account a,TransactionType type,BigDecimal amount,BigDecimal balance,String transfer,String desc){Transaction t=new Transaction();String ref;do{ref="TXN-"+UUID.randomUUID().toString().replace("-","").substring(0,20).toUpperCase();}while(transactionRepository.existsByTransactionReference(ref));t.setTransactionReference(ref);t.setAccount(a);t.setTransactionType(type);t.setAmount(amount);t.setBalanceAfter(balance);t.setTransferReference(transfer);t.setDescription(desc);t.setCreatedAt(LocalDateTime.now());return t;}
    private Account getAccount(String n){if(n==null||n.isBlank())throw new AccountNotFoundException("Account number is required");return accountRepository.findByAccountNumber(n.trim()).orElseThrow(()->new AccountNotFoundException("Account not found with account number: "+n));}
    private Account getAccountForUpdate(String n){if(n==null||n.isBlank())throw new AccountNotFoundException("Account number is required");return accountRepository.findByAccountNumberForUpdate(n.trim()).orElseThrow(()->new AccountNotFoundException("Account not found with account number: "+n));}
    private void validateActive(Account a){if(a.getStatus()!=AccountStatus.ACTIVE)throw new AccountOperationException("Account is not active");if(a.getCustomer().getStatus()!=CustomerStatus.ACTIVE)throw new AccountOperationException("Customer is not active");}
    private BigDecimal validateAmount(BigDecimal amount){if(amount==null)throw new AccountOperationException("Amount is required");if(amount.compareTo(BigDecimal.ZERO)<=0)throw new AccountOperationException("Amount must be greater than zero");if(amount.scale()>2)throw new AccountOperationException("Amount cannot have more than 2 decimal places");return money(amount);}
    private BigDecimal money(BigDecimal amount){return amount.setScale(2,RoundingMode.HALF_UP);}
    private TransactionResponse toResponse(Transaction t){TransactionResponse r=new TransactionResponse();r.setId(t.getId());r.setTransactionReference(t.getTransactionReference());r.setAccountNumber(t.getAccount().getAccountNumber());r.setTransactionType(t.getTransactionType());r.setAmount(t.getAmount());r.setBalanceAfter(t.getBalanceAfter());r.setTransferReference(t.getTransferReference());r.setDescription(t.getDescription());r.setCreatedAt(t.getCreatedAt());return r;}
}
